import { combineReducers } from 'redux'

import axios from "axios";

// export const fetchCampuses = () => {};
const initialState = [];


//Action lType
const SET_CAMPUSES = 'SET_CAMPUSES'

//AN ACTION HAS A TYPE AND IT CAN HAVE A PAYLOAD- SOME OTHER VARIABLE

const setCampuses = (campuses) => ({type: SET_CAMPUSES, campuses})


export const fetchCampuses = () => {
  return async (dispatch, _, { axios }) => {
    const { data } = await axios.get('/api/campuses')
    dispatch(setCampuses(data))
  }
}

const campusesReducer = (state = [], action) => {
  switch (action.type) {
    case SET_CAMPUSES:
      return [...action.campuses]
    default:
      return state
  }
}

const combinedReducer = combineReducers({
    campuses: campusesReducer,
  })

export default combinedReducer
