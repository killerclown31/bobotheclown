export const setStudents = () => {};

export const fetchStudents = () => {};

// Take a look at app/redux/index.js to see where this reducer is
// added to the Redux store with combineReducers
export default function studentsReducer() {
  return null;
}
