import React from 'react'
import { connect } from 'react-redux'
import { fetchCampuses } from "../redux/campuses"


class CampusList extends React.Component {
  componentDidMount(){
    this.props.fetchCampuses()
  }

render(){
  console.log(this.props)
  return (

   <div className="campusList">
      {this.props.campuses.map((campus) => (
        <div key ={campus.id} className="campus">
          <h2>{campus.name} </h2>
          <h3>{campus.location} </h3>
          <p>{campus.discription} </p>
          <h4>{campus.address} </h4>
          <img src = {campus.imageUrl} />
        </div>
      ))}
   </div>
      )
  }
}

const mapStateToProps = (reduxState) => {
  return {
    campuses: reduxState.campuses,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchCampuses: () => dispatch(fetchCampuses()),
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(CampusList)
