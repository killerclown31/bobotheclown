// import { render } from "enzyme";
import React from "react"
import { BrowserRouter as Router } from "react-router-dom";
import { Route, Link } from 'react-router-dom'
import CampusList from './CampusList'

const Routes = () => {
    return (
      <Router>
      <div>
        <nav>Welcome!</nav>
        <main>
          <h1>Welcome to the Interplanatry Schools List</h1>
          <p>This seems like a nice place to get started with some Routes!</p>
          <Route path='/campuses' component={CampusList} />

        </main>
      </div>
   </Router>)


}

export default Routes;
