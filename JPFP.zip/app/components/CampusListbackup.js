import React from 'react'
import { connect } from 'react-redux'
import { fetchCampuses } from "../redux/campuses"
import { NavLink } from 'react-router-dom'


class CampusListItem extends React.Component {

  constructor(props){
    super(props)
  }

render() {
  const {campus} = this.props;
  return(

    <div className="indyCampuses">
        <NavLink to={`/campuses/${campus.id}`} activeClassName="active">{campus.name}
           <img className="media-object" src={campus.image} alt="image" />
        </NavLink>
        <button
            className="btn btn-default btn-xs"
            onClick={ () => this.props.removeCampus(campus.id) }>
            <span className="glyphicon glyphicon-remove" />
        </button>
      </div>
  )
  }

}


const mapStateToProps = (reduxState) => {
  return {
    campuses: reduxState.campuses,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchCampuses: () => dispatch(fetchCampuses()),
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(CampusList)
