const { green, red } = require("chalk");
const { db } = require("./server/db");
const { database, Campus, Student } = require("./server/db")

const seed = async () => {
  try {
    await db.sync({ force: true });
//Campus Seed
 const marsAcademy = await Campus.create({
      name: "Mars Academy",
      imageUrl: "public/images/marsAcademy.png",
      address: "122 Mars lane, New New York 11218, United States of Mars: Mars",
      description: "Mars Academy is the best school in the solar system",
      StudentId: 1

    });
    const jupiterJumpstart = await Campus.create({
      name: "Jupiter Jumpstart",
      imageUrl: "public/images/jupiterJumpstart.png",
      address: "5.2 AU",
      description: "The best JavaScript Academy for toddlers in the solar system",
    });
    const plutoConservatory = await Campus.create({
      name: "Pluto Conservatory",
      imageUrl: "public/images/plutoConservatory.png",
      address: "3803 Evergreen Tarris, New London, United Kingdom of Pluto: Pluto",
      description: "Pluto Conservatory is great, but it's really cold and we are not a plannet anyomore",
    });
    const artInstituteOfMercury = await Campus.create({
      name: "Art Institute of Mercury",
      imageUrl: "public/images/artInstituteOfMercury.png",
      address: "2905 Palmerston Rd, New Madrid XZ5-302, Spanish Mercury: Mercury",
      description: "The Art Institute of Mercury is the hotest school in the galaxy",
    });

    //Students Seed
    const maeJemison = await Student.create({
      firstName: "Mae",
      lastName: "Jemison",
      email: "maeJemison@gmail.com",
      imageUrl: "public/images/maeJemsion.png",
      gpa: 3.9,
      CampusId: 1
    });
    const sallyRide = await Student.create({
      firstName: "Sally",
      lastName: "Ride",
      email: "sallyride@nasa.gov",
      imageUrl: "public/images/sallyRide.png",
      gpa: 3.8,
      CampusId: 2
    });
    const maryShelley = await Student.create({
      firstName: "Mary",
      lastName: "Shelley",
      email: "mshelley@frankenstein.com",
      imageUrl: "public/images/maryShelley.png",
      gpa: 3.1,
      CampusId: 2
    });
    const adaLovelace = await Student.create({
      firstName: "Ada",
      lastName: "Lovelace",
      email: "Adathepotata@potato.com",
      imageUrl: "public/images/adaLovelace.png",
      gpa: 1.1,
      CampusId: 1
    });
  } catch (err) {
    console.log(red(err));
  }
};

module.exports = seed;
// If this module is being required from another module, then we just export the
// function, to be used as necessary. But it will run right away if the module
// is executed directly (e.g. `node seed.js` or `npm run seed`)
if (require.main === module) {
  seed()
    .then(() => {
      console.log(green("Seeding success!"));
      db.close();
    })
    .catch(err => {
      console.error(red("Oh noes! Something went wrong!"));
      console.error(err);
      db.close();
    });
}
