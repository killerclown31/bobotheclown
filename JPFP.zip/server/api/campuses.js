const Campus = require('../db/campus.js');
const router = require('express').Router();
const Student = require('../db/student.js')
// const { request } = require('./index');
// const {
//   models: { Campus, Student },
// } = require('../index');

// router.get('/campus', async (req, res, next) => {
//   try {
//     const campus = await Campus.findAll();
//     console.log("aaa", campus)
//     res.json(campus)
//   }
//   catch (err) {
//     next(err);
//   }
// });


// module.exports = router
