// The purpose of this module is to bring your Sequelize instance (`db`) together
// with your models, for which you'll find some blank files in this directory:

const db = require('./database')
const Student = require('./student')
const Campus = require('./campus')

// This is a great place to establish associations between your models
// (https://sequelize-guides.netlify.com/association-types/).
// Example:
//
// Puppy.belongsTo(Owner)


Campus.hasMany(Student, { foreignKey: Campus.id});
// Student.hasOne(Campus, { foreignKey: Student.id});




Student.prototype.getCampus = async function () {
  const studentsCampus = await Campus.findOne();
  console.log("zzzz", studentsCampus)
  return studentsCampus;
};

Campus.prototype.hasStudents = async function(studentArr) {
  const allStudents = await Student.findAll();
  console.log('yyyy', allStudents)
  // logic to see if the students were returned
  // return true if we got the students / else false
  // response: [ {dataValues: {id: 1}}, {dataValues: {id: 2}}]
  const studentIds = allStudents.map((student) => {
    return student.dataValues.id
  })

  studentArr.forEach((student) => {
    console.log("STUDENTZ: ", student)
    if (!studentIds.includes(student.dataValues.id)) {
      return false
    }
  })
  return true
}

module.exports = {
  // Include your models in this exports object as well!
  db,
  Student,
  Campus,
}
